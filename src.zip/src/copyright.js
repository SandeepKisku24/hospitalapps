import React from "react";

const copyright = ()=>{
    return(
        <div className="copyrightBar">
            <span class="material-symbols-outlined">copyright</span>
             Copyright Mercy Hospital Poreyahat 2024
            </div>
    )
}
export default copyright;