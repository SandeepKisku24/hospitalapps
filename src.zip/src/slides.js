import React from "react";
import slide from "./slide1.1.jpg"
const Slide = ()=>{
    return(
        <div className="slide">
            <img src={slide}></img>
        </div>
    )
}
export default Slide;